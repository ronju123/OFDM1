clc;

%SDR Software Example: EE 5283

noisevar=5e-9;
%noisevar=11.8e-4;

%Generate Object a
NumSubFrames=4; %1, 2, 3, 4;
CPType = 'Normal';  %Normal, Extended
switch CPType
    case 'Normal'
        NumSymbols=7*NumSubFrames;
    case 'Extended'
        NumSymbols=6*NumSubFrames;
end

fs =7.68e6;  %7.68, 15.36, 30.72 MHz
DataType = 'Info';  %Synch, Info
Modulation='QPSK';
%%%%%%Matlab Information Source: Students, use this in your Matlab CODE
BitsPerSymbol=[];
ChannelType='AWGN';  %AWGN, Fading

switch ChannelType
    case 'Fading'
        hinit=[0.5, 0, 0, 0, 0, 1+1i, 0, 0, 0, 0, -1-1i];  %fading channel
    case 'AWGN'
        hinit=[1,0]; %AWGN
end

a=OFDMsymbol2(hinit,noisevar,Modulation, CPType, fs, DataType);  %constructor

binary_info_all = zeros(1,NumSymbols*a.BitsPerSymbol);
dataouty_all = zeros(1, NumSymbols*(a.CP+a.NFFT)+length(hinit)-1);
for L=1:NumSymbols
    switch DataType
        case 'Info'
            binary_info=randi([0,1],1,a.BitsPerSymbol);
            binary_info_all(1,(L-1)*size(binary_info,2)+1:L*size(binary_info,2))=binary_info;
            [dataout, CoeffTable, Coeff2]=RunOFDMSymbolGeneration(a,binary_info); %method in the class Baseband2
            ptrval1=(L-1)*(a.CP+a.NFFT)+1;
            dataouty_all(1,ptrval1:ptrval1+length(dataout.y)-1) = dataout.y + dataouty_all(1,ptrval1:ptrval1+length(dataout.y)-1);
        case 'Synch'
            [dataout, CoeffTable, Coeff2]=RunOFDMSymbolGeneration(a); %method in the class Baseband2
            ptrval1=(L-1)*(a.CP+a.NFFT)+1;
            dataouty_all(1,ptrval1:ptrval1+length(dataout.y)-1) = dataout.y + dataouty_all(1,ptrval1:ptrval1+length(dataout.y)-1);
    end
end

y2=dataouty_all;
if strcmp(ChannelType, 'AWGN')==1
        [binary_recov, datarec]=RunOFDMDecode(a,y2,NumSymbols);
        if strcmp(a.DataType,'Info')==1
            ErrorCount=sum(xor(binary_info_all,binary_recov));
            ErrorRate=ErrorCount/length(binary_info_all);
        end
end
