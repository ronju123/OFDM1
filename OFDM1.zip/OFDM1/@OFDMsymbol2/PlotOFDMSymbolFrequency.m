function PlotOFDMSymbolFrequency(obj, plottype, plotnum)
figure(plotnum);
xaxisR='Index';
yaxisR='Re Output';
ztitleR='Real Output of Discrete LTI Channel';
xaxisI='Index';
yaxisI='Im Output';
ztitleI='Imag Output of Discrete LTI Channel';

xdat=20*log10(abs(fft(obj.y, obj.NFFT)));
xax1=[0:obj.NFFT-1]*(obj.NFFT*15e3)/obj.NFFT;

switch plottype
    case 'continuous'
        plot(xax1, xdat);
        xlabel('Hz');
        ylabel('Amplitude dB');
        title(ztitleR);
        
        
    case 'discrete'
        stem(xax1, real(xdat));
        xlabel(xaxisR);
        ylabel(yaxisR);
        title(ztitleR);
    otherwise
        error('unrecognized plottype')
end

