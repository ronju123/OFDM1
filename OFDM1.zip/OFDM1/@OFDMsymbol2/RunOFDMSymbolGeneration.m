function varargout=RunOFDMSymbolGeneration(varargin)
dbstop if error
obj=varargin{1};
switch obj.DataType
    case 'Synch'
        obj.freqbins(obj.bins_used)=obj.SynchChan;
        tmpval1=ifft(obj.freqbins, obj.NFFT);
        xdat1=[tmpval1(end-obj.CP+1:end), tmpval1];
        CoeffTable=obj.SynchChan;
    case 'Info'
        xin=varargin{2};
        [CoeffTable, xdat1] = RunBinaryMap(obj, xin);
end
CoeffTable0a=fft(xdat1(obj.CP+1:obj.CP+obj.NFFT),obj.NFFT);
xbins=[(-obj.NFFT/2:-1)+(obj.NFFT+1),(1:obj.NFFT/2)];
CoeffTable0=CoeffTable0a(xbins).';
z=conv(obj.h, xdat1);
vnoise=sqrt(obj.v/2)*randn(size(z))+1i*sqrt(obj.v/2)*randn(size(z));
obj.y=z+vnoise;
varargout{1}=obj;
varargout{3}=CoeffTable0;
varargout{2}=CoeffTable.';

