            function varargout=RunBinaryMap(obj, xin0)
               
            
                switch obj.MappingType
                    case 'BPSK'
                                    
                        MapBPSK=[-1,1];
                        indexdat=xin0+1;
                        dataout0=MapBPSK(indexdat);
                        obj.freqbins(obj.bins_used)=dataout0;
                        tmpval1=ifft(obj.freqbins, obj.NFFT); 
                        dataout1=[tmpval1(end-obj.CP+1:end), tmpval1]; 
                        
                        
                        %Mapping
                        %b0-->-1
                        %b1-->+1;
                        %dataout1=2*xin-1; 
                    case 'QPSK'
                        symblen=obj.NFFT+obj.CP;
                        
                        MapQPSK=[exp(1i*2*pi*(1/8)), exp(1i*2*pi*(3/8)), exp(1i*2*pi*(7/8)), exp(1i*2*pi*(5/8))];
                        indexdat=xin0(1:2:end)*2+xin0(2:2:end)+1;
                        dataout0=MapQPSK(indexdat);   
                        obj.freqbins(obj.bins_used)=dataout0;
                        tmpval1=ifft(obj.freqbins, obj.NFFT); 
                        dataout1=[tmpval1(end-obj.CP+1:end), tmpval1];
                        
                        %Currently unsupported
                end


   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%



varargout{1}=dataout0;
varargout{2}=dataout1;
            end
           
