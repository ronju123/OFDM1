function varargout = RunOFDMCFOE(obj, InChann, Ts, fd, Coeff2)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
dbstop if error
ptr1=obj.CP+1;

dvec1=fft(InChann(ptr1:ptr1+obj.NFFT-1),obj.NFFT);
bins_used=[obj.NFFT/2+1:obj.NFFT,1:obj.NFFT/2];
dvec=Coeff2(bins_used);
Hk=fft(obj.h,obj.NFFT);
HM=diag(Hk);
W=(1/obj.NFFT)*exp(1i*2*pi*(0:obj.NFFT-1)'*(0:obj.NFFT-1)/obj.NFFT);
Pv=exp(1i*2*pi*fd*Ts*(obj.CP+1:obj.CP+obj.NFFT));
PM=diag(Pv);
x=PM*W*HM*dvec;
y=InChann(ptr1:ptr1+obj.NFFT-1).';
figure(5);
subplot(2,1,1), plot(1:length(x),real(x),'k',1:length(x),real(y),'b')
subplot(2,1,2), plot(1:length(x),imag(x),'k',1:length(y),imag(y),'b')
dbg77=1;
varargout{1}=b1a;
varargout{2}=b2.';

end



