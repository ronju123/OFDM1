function varargout = RunOFDMDecode(obj, InChann, NumSymbs)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
dbstop if error

b1a_long=zeros(1,NumSymbs*obj.BitsPerSymbol);
b2a_long=zeros(1,length(obj.bins_used)*NumSymbs);
for LP=1:NumSymbs
    ptr1=(LP-1)*(obj.NFFT+obj.CP)+obj.CP+1;
    
    dvec=fft(InChann(ptr1:ptr1+obj.NFFT-1),obj.NFFT);
    ExtractBins=dvec(obj.bins_used);
    if strcmp(obj.DataType,'Info')==1
        ZCmet=(repmat(exp(1i*(2*pi/8)*([1,3,7,5])),length(obj.bins_used),1)).';
        ExtractedBins1=repmat(ExtractBins, [4,1]);
        [a1,b1]=min(abs(ExtractedBins1-ZCmet));
        b1a=zeros(1,2*length(b1));
        b2=zeros(size(b1));
        for La=1:length(b1)
            switch b1(La)
                case 1
                    b1a(2*(La-1)+1)=0;
                    b1a(2*La)=0;
                    b2(La)=exp(1i*(2*pi/8)*(1));
                case 2
                    b1a(2*(La-1)+1)=0;
                    b1a(2*La)=1;
                    b2(La)=exp(1i*(2*pi/8)*(3));
                case 3
                    b1a(2*(La-1)+1)=1;
                    b1a(2*La)=0;
                    b2(La)=exp(1i*(2*pi/8)*(7));
                case 4
                    b1a(2*(La-1)+1)=1;
                    b1a(2*La)=1;
                    b2(La)=exp(1i*(2*pi/8)*(5));
            end
        end
        if LP==1;
            varargout{2}=b2.';
        end
        b1a_long(1,(LP-1)*size(b1a,2)+1:LP*size(b1a,2))=b1a;
    end
    
    switch obj.DataType
        case 'Info'
            b2a_long(1,(LP-1)*length(obj.bins_used)+1 ...
                :LP*length(obj.bins_used))=b2;
        case 'Synch'
            b2a_long(1,(LP-1)*length(obj.bins_used)+1 ...
                :LP*length(obj.bins_used))=ExtractBins;
    end
    
end
dbg77=1;
varargout{1}=b1a_long;
varargout{2}=b2a_long;

end



