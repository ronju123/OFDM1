function PlotOFDMSymbolTime(obj, plottype, plotnum)
figure(plotnum)
xaxisR='Index';
yaxisR='Re Output';
ztitleR='Real Output of Discrete LTI Channel';
xaxisI='Index';
yaxisI='Im Output';
ztitleI='Imag Output of Discrete LTI Channel';


switch plottype
    case 'continuous'
        subplot(2,1,1), plot(real(obj.y));
        xlabel(xaxisR);
        ylabel(yaxisR);
        title(ztitleR);
        subplot(2,1,2), plot(imag(obj.y));
        xlabel(xaxisI);
        ylabel(yaxisI);
        title(ztitleI);
        
    case 'discrete'
        subplot(2,1,1), stem(real(obj.y));
        xlabel(xaxisR);
        ylabel(yaxisR);
        title(ztitleR);
        subplot(2,1,2), stem(imag(obj.y));
        xlabel(xaxisI);
        ylabel(yaxisI);
        title(ztitleI);
    otherwise
        error('unrecognized plottype')
end

