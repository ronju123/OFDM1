function [ OutPut ] = SyncChanOFDM(varargin)
%synchronization channel
dbstop if error
%p=23;
%N=64;
%SMode
%plotnum
%g2
%nvar=0.1;
for LB=1:nargin
    switch LB
        case 1
            p=varargin{1};
        case 2
            N=varargin{2};
            if rem(N,2)==0
                NB1=-N/2;
                NE1=N/2-1;
                NARG1=NB1:NE1;
                g=exp(-1i*(2*pi/N)*p*NARG1.^2/2);
            else
                NB1=-(N-1)/2;
                NE1= (N-1)/2;
                NARG1=NB1:NE1;
                g=exp(-1i*(2*pi/N)*p*(NARG1.*(NARG1+1))/2);
            end
        case 3
            SMode = varargin{3};
        case 4
            plotnum=varargin{4};
        case 5
            g2=varargin{5};
            k=0;
            for tau=NB1:NE1
                k=k+1;
                xax(k)=tau;
                r(k)=(1/N)*sum(conj(g).*g2([rem(tau+N,N)+1:N,1:rem(tau+N,N)]));
            end
    end
end



switch SMode
    case 'Correlation'
        if plotnum~=0
            figure(plotnum)
            plot(xax,abs(r))
            xlabel('index')
            ylabel('|Correlation|')
            titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
            title(titleSTR);
            figure(plotnum+1)
            subplot(2,1,1), plot(xax,real(r));
            xlabel('index')
            ylabel('Real Correlation')
            titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
            subplot(2,1,2), plot(xax,imag(r));
            xlabel('index')
            ylabel('Imag Correlation')
            titleSTR=strcat({'Cyclic AutoCorrelation of Zadoff Chu: Prime='},{num2str(p)},{', N='},{num2str(N)});
        end
        OutPut = r;
    case 'SynchFunc'
     if plotnum~=0
            figure(plotnum)
            subplot(2,1,1), plot(1:length(g),real(g));
            xlabel('index')
            ylabel('Real G')
            titleSTR=strcat({'Zadoff Chu Synch Channel: Prime='},{num2str(p)},{', N='},{num2str(N)});
            subplot(2,1,2), plot(1:length(g),imag(g));
            xlabel('index')
            ylabel('Imag Correlation')
            titleSTR=strcat({'Zadoff Chu Synch: Prime='},{num2str(p)},{', N='},{num2str(N)});
        end
        OutPut = g;
end
end



