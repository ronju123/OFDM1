classdef OFDMsymbol2 < handle
    
    %
    %   Detailed explanation goes here
    
    properties
        h=[1.0, 3.0, -1];  %defualt channel
        v=0.1; %default noise variance
        y=[]; %null output vector
        MappingType= 'BPSK'; %modulation
        BitsPerPhasor = 1;
        NFREQ=2^16;  %size of FFT Plot
        L=4; %Number of OFDM Symbols
        NFFT=16;
        CP=1;
        CPvec=[];
        CPType='Normal';
        freqbins=[];
        bins_used=[];
        Rblocks=[];
        ZC12=[];
        BitsPerFrame=[];
        BitsPerSymbol=[];
        ACKNACKcase=0;
        fs=[];
        DeltaF = 15e3;
        SynchChan = [];
        DataType = 'Info';
        SymbolPtr = 0;
    end
    
    methods   %constructor method
        function obj=OFDMsymbol2(varargin)
            
            for k=1:nargin
                switch k
                    case 1
                        obj.h=varargin{1};
                    case 2
                        obj.v=varargin{2};
                    case 3
                        obj.MappingType=varargin{3};
                    case 4
                        obj.CPType=varargin{4};
                    case 5
                        obj.fs=varargin{5};
                        switch obj.fs
                            case 7.68e6
                            case 15.36e6
                            case 30.72e6
                            otherwise
                                error('Unsupported Sampling Frequency');
                        end
                        obj.NFFT=round(obj.fs*2048/30.72e6);
                    case 6
                        obj.DataType=varargin{6};
                end
            end
            atmp = -obj.NFFT/2+1:-1;
            btmp = 1:obj.NFFT/2-1;
            atmp1= atmp+obj.NFFT+1;
            btmp1= btmp+1;
            obj.bins_used = [atmp1, btmp1];
            obj.NFFT=obj.fs/obj.DeltaF;
            obj.freqbins=zeros(1, obj.NFFT);
            switch obj.MappingType
                case 'BPSK'
                   obj.BitsPerPhasor=1;
                   obj.BitsPerSymbol=length(obj.bins_used)*1;
                case 'QPSK'
                   obj.BitsPerPhasor=2;
                   obj.BitsPerSymbol=length(obj.bins_used)*2;
            end
            
            switch obj.CPType
                case 'Normal'
                  SlotCP1=obj.fs*(0.5e-3)-7*(obj.NFFT);
                  CP1=floor(SlotCP1/7);
                  CP2=SlotCP1-7*CP1;
                  obj.CPvec=[(CP1+1)*ones(1,CP2),CP1*ones(1,7-CP2)];
                  obj.CP=obj.CPvec(obj.SymbolPtr+1);
                case 'Extended'
                  SlotCP1=obj.fs*(0.5e-3)-6*(obj.NFFT);
                  CP1=floor(SlotCP1/6);
                  CP2=SlotCP1-6*CP1;
                  obj.CPvec=[(CP1+1)*ones(1,CP2),CP1*ones(1,6-CP2)];
                  obj.CP=obj.CPvec(obj.SymbolPtr+1);
            end
            
            switch obj.DataType
                case 'Synch'
                    SMode = 'SynchFunc'; %SynchFunc, Correlation
                    p=23;
                    plotnum=0;
                    obj.SynchChan=SyncChanOFDM(p, length(obj.bins_used), SMode, plotnum) ;
            end
        end
    end
    
end

